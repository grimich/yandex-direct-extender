# yandex-direct-extender
Adds some buttons to improve UI of direct.yandex.ru
