function checkForValidUrl(tabId, changeInfo, tab) {
	if (tab.url.indexOf('direct.yandex') > -1) {
	alert("ok"!);	
	chrome.pageAction.show(tabId);
	}
	else
	{alert("wow"!);};
};

chrome.tabs.onUpdated.addListener(checkForValidUrl);

chrome.pageAction.onClicked.addListener(function(tab) {
	chrome.tabs.executeScript(tab.id, {file: "script.js"});
});